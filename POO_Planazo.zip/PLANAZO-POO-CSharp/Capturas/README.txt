Guarda en esta carpeta capturas reales de la aplicación ejecutándose y de los casos de prueba solicitados por el profesor. No reemplaces las capturas por imágenes inventadas.
