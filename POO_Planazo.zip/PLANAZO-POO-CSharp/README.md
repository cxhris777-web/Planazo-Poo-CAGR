# PLANAZO — Sistema de eventos y reservas

Aplicación de consola desarrollada en C# y .NET para consultar eventos, reservar entradas, controlar cupos, cancelar reservas y consultar un resumen de las reservas activas. El proyecto aplica los principios de Programación Orientada a Objetos solicitados en el parcial.

## Funcionalidades

- Lista siete eventos iniciales: dos películas, dos conciertos, dos talleres y un evento deportivo adicional.
- Consulta de eventos por identificador y visualización de precios/cupos.
- Cálculo polimórfico del precio final: Cine conserva el precio base, Concierto aplica 15 % de incremento y Taller aplica 10 % de descuento. EventoDeportivo aplica 8 % de incremento como reto adicional.
- Creación de reservas con validación de cantidades y cupos.
- Cancelación de reservas con devolución de cupos y prevención de cancelación duplicada.
- Listado de reservas, consulta por usuario y resumen de reservas activas.
- Manejo de errores para que las entradas inválidas no cierren inesperadamente el programa.

## Requisitos

- .NET 8 SDK o una versión compatible con el archivo del proyecto.
- Terminal (PowerShell, CMD, Windows Terminal o terminal de VS Code).

## Cómo ejecutar

1. Descarga o clona el repositorio.
2. Abre una terminal en la carpeta que contiene `PLANAZO-POO-CSharp.csproj`.
3. Ejecuta:

   ```bash
   dotnet run
   ```

## Organización de las clases

- `Program.cs`: menú de consola, lectura de datos y presentación de resultados. No contiene la lógica central de reservas.
- `Modelos/Evento.cs`: clase abstracta con atributos comunes y control de cupos.
- `Modelos/Cine.cs`: precio final igual al precio base.
- `Modelos/Concierto.cs`: precio base más 15 %.
- `Modelos/Taller.cs`: precio base menos 10 %.
- `Modelos/EventoDeportivo.cs`: tipo adicional que aplica 8 % de incremento.
- `Modelos/Usuario.cs`: identifica a quien realiza reservas.
- `Modelos/Reserva.cs`: relaciona usuario y evento, guarda entradas, total y estado.
- `Servicios/GestorReservas.cs`: administra colecciones, eventos, usuarios, reservas, cancelaciones y resumen.
- `Capturas/`: espacio para agregar las capturas reales de las pruebas ejecutadas.

## Conceptos de POO aplicados

- **Abstracción:** `Evento` representa los datos y comportamientos comunes; no se instancia directamente.
- **Encapsulamiento:** las propiedades que pueden cambiar tienen setters privados; los cupos se modifican mediante `ReservarCupos()` y `DevolverCupos()`.
- **Herencia:** `Cine`, `Concierto`, `Taller` y `EventoDeportivo` heredan de `Evento`.
- **Polimorfismo:** cada tipo implementa `CalcularPrecioFinal()`. El gestor puede trabajar con objetos del tipo base `Evento` sin conocer la clase concreta.
- **Constructores:** validan e inicializan objetos.
- **Colecciones:** `List<Evento>`, `List<Reserva>` y `List<Usuario>` almacenan los datos durante la ejecución.
- **Asociación/composición:** `Reserva` referencia el usuario y el evento reservados; `GestorReservas` administra las colecciones.
- **Excepciones:** las validaciones generan excepciones controladas, que el menú captura y muestra sin finalizar inesperadamente la aplicación.
- **Dinero:** los precios y totales se manejan con `decimal`.

## Casos de prueba que se deben ejecutar y capturar

1. Hacer una reserva válida y verificar que bajan los cupos.
2. Intentar reservar más entradas que las disponibles.
3. Intentar reservar cero entradas y una cantidad negativa.
4. Cancelar una reserva y comprobar que los cupos regresan.
5. Intentar cancelar nuevamente la misma reserva.
6. Consultar un ID de evento inexistente.
7. Comparar los precios de Cine, Concierto y Taller. Por ejemplo, un concierto con base de $50.000 debe costar $57.500.
8. Ver el resumen y confirmar que solo cuenta las reservas activas.

**Importante:** las capturas deben tomarse después de ejecutar y probar el programa en el equipo del estudiante. Coloca las imágenes dentro de `Capturas/` y agrega sus referencias aquí antes de entregar.

## Diagrama de clases UML

```mermaid
classDiagram
    class Evento {
      <<abstract>>
      +int Id
      +string Nombre
      +DateTime Fecha
      +decimal PrecioBase
      +int CapacidadMaxima
      +int CuposDisponibles
      +CalcularPrecioFinal() decimal
      +ReservarCupos(cantidad) void
      +DevolverCupos(cantidad) void
    }
    class Cine
    class Concierto
    class Taller
    class EventoDeportivo
    class Usuario {
      +int Id
      +string Nombre
    }
    class Reserva {
      +int Id
      +int CantidadEntradas
      +decimal ValorTotal
      +EstadoReserva Estado
      +MarcarCancelada() void
    }
    class GestorReservas {
      +RegistrarEvento(evento) void
      +CrearReserva(nombre, eventoId, cantidad) Reserva
      +CancelarReserva(id) void
      +ReservasPorUsuario(usuarioId)
    }
    Evento <|-- Cine
    Evento <|-- Concierto
    Evento <|-- Taller
    Evento <|-- EventoDeportivo
    Reserva --> Evento : reserva
    Reserva --> Usuario : pertenece a
    GestorReservas o-- Evento : administra
    GestorReservas o-- Reserva : administra
    GestorReservas o-- Usuario : administra
```

## Pregunta de sustentación

Utilicé una clase abstracta `Evento` porque Cine, Concierto y Taller comparten atributos y comportamientos, como identificador, nombre, fecha, precio base, capacidad y cupos disponibles. Al centralizarlos en una clase base evito repetir código y puedo aplicar las mismas validaciones de cupos a todos los tipos. El método `CalcularPrecioFinal()` es abstracto porque cada tipo calcula el precio de manera diferente: `Cine` conserva el precio base, `Concierto` aumenta un 15 % y `Taller` descuenta un 10 %. Si se agrega `EventoDeportivo`, basta con heredar de `Evento` e implementar ese método; el gestor puede administrarlo como cualquier otro evento sin cambiar los cálculos existentes. Esto facilita el mantenimiento y la extensión del sistema.

## Antes de entregar

- [ ] Ejecutar `dotnet run` y probar las opciones del menú.
- [ ] Completar los casos de prueba y guardar capturas reales en `Capturas/`.
- [ ] Revisar que el README describa el código final.
- [ ] Crear el repositorio público con el nombre exacto `PLANAZO-POO-CSharp`.
- [ ] Subir todos los archivos y entregar en el EVA únicamente el enlace público del repositorio.
