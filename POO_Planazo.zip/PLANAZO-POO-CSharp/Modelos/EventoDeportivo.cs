namespace Planazo.Modelos;

// Reto adicional: nuevo tipo de evento sin modificar Cine, Concierto ni Taller.
public sealed class EventoDeportivo : Evento
{
    public EventoDeportivo(int id, string nombre, DateTime fecha, decimal precioBase, int capacidadMaxima)
        : base(id, nombre, fecha, precioBase, capacidadMaxima) { }

    public override decimal CalcularPrecioFinal() => Math.Round(PrecioBase * 1.08m, 2);
}
