namespace Planazo.Modelos;

public sealed class Concierto : Evento
{
    public Concierto(int id, string nombre, DateTime fecha, decimal precioBase, int capacidadMaxima)
        : base(id, nombre, fecha, precioBase, capacidadMaxima) { }

    public override decimal CalcularPrecioFinal() => Math.Round(PrecioBase * 1.15m, 2);
}
