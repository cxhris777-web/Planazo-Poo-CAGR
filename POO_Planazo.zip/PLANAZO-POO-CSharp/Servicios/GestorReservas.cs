using Planazo.Modelos;

namespace Planazo.Servicios;

public sealed class GestorReservas
{
    private readonly List<Evento> _eventos = new();
    private readonly List<Reserva> _reservas = new();
    private readonly List<Usuario> _usuarios = new();
    private int _siguienteReservaId = 1;
    private int _siguienteUsuarioId = 1;

    public IReadOnlyList<Evento> Eventos => _eventos.AsReadOnly();
    public IReadOnlyList<Reserva> Reservas => _reservas.AsReadOnly();
    public IReadOnlyList<Usuario> Usuarios => _usuarios.AsReadOnly();

    public void RegistrarEvento(Evento evento)
    {
        ArgumentNullException.ThrowIfNull(evento);
        if (_eventos.Any(e => e.Id == evento.Id)) throw new InvalidOperationException("Ya existe un evento con ese identificador.");
        _eventos.Add(evento);
    }

    public Evento ObtenerEvento(int id) => _eventos.FirstOrDefault(e => e.Id == id)
        ?? throw new KeyNotFoundException($"No existe un evento con ID {id}.");

    public Usuario ObtenerOCrearUsuario(string nombre)
    {
        if (string.IsNullOrWhiteSpace(nombre)) throw new ArgumentException("El nombre es obligatorio.");
        var existente = _usuarios.FirstOrDefault(u => string.Equals(u.Nombre, nombre.Trim(), StringComparison.OrdinalIgnoreCase));
        if (existente is not null) return existente;
        var usuario = new Usuario(_siguienteUsuarioId++, nombre);
        _usuarios.Add(usuario);
        return usuario;
    }

    public Reserva CrearReserva(string nombrePersona, int eventoId, int cantidad)
    {
        if (cantidad <= 0) throw new ArgumentException("La cantidad de entradas debe ser mayor que cero.");
        var evento = ObtenerEvento(eventoId);
        if (cantidad > evento.CuposDisponibles)
            throw new InvalidOperationException($"No hay suficientes cupos. Disponibles: {evento.CuposDisponibles}.");

        var usuario = ObtenerOCrearUsuario(nombrePersona);
        // Primero se valida todo; luego se actualizan los cupos y se registra la reserva.
        evento.ReservarCupos(cantidad);
        var reserva = new Reserva(_siguienteReservaId++, usuario, evento, cantidad);
        _reservas.Add(reserva);
        return reserva;
    }

    public Reserva ObtenerReserva(int id) => _reservas.FirstOrDefault(r => r.Id == id)
        ?? throw new KeyNotFoundException($"No existe una reserva con ID {id}.");

    public void CancelarReserva(int id)
    {
        var reserva = ObtenerReserva(id);
        if (reserva.Estado == EstadoReserva.Cancelada)
            throw new InvalidOperationException("Esta reserva ya fue cancelada.");
        reserva.Evento.DevolverCupos(reserva.CantidadEntradas);
        reserva.MarcarCancelada();
    }

    public IEnumerable<Reserva> ReservasPorUsuario(int usuarioId) =>
        _reservas.Where(r => r.Usuario.Id == usuarioId);

    public int CantidadReservasActivas => _reservas.Count(r => r.Estado == EstadoReserva.Activa);
    public int CantidadEntradasActivas => _reservas.Where(r => r.Estado == EstadoReserva.Activa).Sum(r => r.CantidadEntradas);
    public decimal ValorTotalActivo => _reservas.Where(r => r.Estado == EstadoReserva.Activa).Sum(r => r.ValorTotal);
}
