using System.Globalization;
using Planazo.Modelos;
using Planazo.Servicios;

CultureInfo.CurrentCulture = CultureInfo.GetCultureInfo("es-CO");
var gestor = new GestorReservas();
CargarEventosIniciales(gestor);

Console.WriteLine("Bienvenido a PLANAZO - Sistema de eventos y reservas");
while (true)
{
    MostrarMenu();
    Console.Write("Seleccione una opción: ");
    string? opcion = Console.ReadLine();
    Console.WriteLine();
    try
    {
        switch (opcion)
        {
            case "1": VerEventos(gestor); break;
            case "2": ConsultarEvento(gestor); break;
            case "3": ReservarEntradas(gestor); break;
            case "4": VerReservas(gestor); break;
            case "5": CancelarReserva(gestor); break;
            case "6": VerResumen(gestor); break;
            case "0": Console.WriteLine("Gracias por utilizar PLANAZO. ¡Hasta pronto!"); return;
            default: Console.WriteLine("Opción no válida. Seleccione una opción del menú."); break;
        }
    }
    catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or KeyNotFoundException or FormatException or OverflowException)
    {
        Console.WriteLine($"No se pudo completar la operación: {ex.Message}");
    }
    Console.WriteLine("\nPresione ENTER para continuar...");
    Console.ReadLine();
    Console.Clear();
}

static void MostrarMenu()
{
    Console.WriteLine("================================");
    Console.WriteLine("        PLANAZO - EVENTOS");
    Console.WriteLine("================================");
    Console.WriteLine("1. Ver eventos disponibles");
    Console.WriteLine("2. Consultar evento");
    Console.WriteLine("3. Reservar entradas");
    Console.WriteLine("4. Ver reservas realizadas");
    Console.WriteLine("5. Cancelar una reserva");
    Console.WriteLine("6. Ver resumen de reservas");
    Console.WriteLine("0. Salir");
    Console.WriteLine();
}

static void CargarEventosIniciales(GestorReservas gestor)
{
    var fecha = DateTime.Today;
    gestor.RegistrarEvento(new Cine(1, "Interestelar", fecha.AddDays(7).AddHours(18), 18000m, 80));
    gestor.RegistrarEvento(new Cine(2, "Coco", fecha.AddDays(8).AddHours(16), 15000m, 70));
    gestor.RegistrarEvento(new Concierto(3, "Noche de Rock", fecha.AddDays(14).AddHours(20), 50000m, 200));
    gestor.RegistrarEvento(new Concierto(4, "Festival de Pop", fecha.AddDays(21).AddHours(19), 65000m, 250));
    gestor.RegistrarEvento(new Taller(5, "Introducción a C#", fecha.AddDays(5).AddHours(9), 40000m, 30));
    gestor.RegistrarEvento(new Taller(6, "Fotografía creativa", fecha.AddDays(10).AddHours(10), 35000m, 25));
    // Reto adicional 1: séptimo evento de tipo nuevo.
    gestor.RegistrarEvento(new EventoDeportivo(7, "Encuentro deportivo", fecha.AddDays(18).AddHours(15), 30000m, 100));
}

static void VerEventos(GestorReservas gestor)
{
    Console.WriteLine("EVENTOS DISPONIBLES");
    foreach (var evento in gestor.Eventos) Console.WriteLine(evento);
}

static void ConsultarEvento(GestorReservas gestor)
{
    int id = LeerEntero("Ingrese el ID del evento: ");
    Console.WriteLine(gestor.ObtenerEvento(id));
}

static void ReservarEntradas(GestorReservas gestor)
{
    Console.Write("Nombre de la persona: ");
    string nombre = Console.ReadLine() ?? string.Empty;
    int eventoId = LeerEntero("ID del evento: ");
    int cantidad = LeerEntero("Cantidad de entradas: ");
    var reserva = gestor.CrearReserva(nombre, eventoId, cantidad);
    Console.WriteLine("Reserva realizada correctamente:");
    Console.WriteLine(reserva);
}

static void VerReservas(GestorReservas gestor)
{
    if (gestor.Reservas.Count == 0) { Console.WriteLine("Todavía no hay reservas registradas."); return; }
    foreach (var reserva in gestor.Reservas) Console.WriteLine(reserva);
    Console.WriteLine("\nConsultar reservas por usuario");
    Console.WriteLine("Usuarios registrados:");
    foreach (var usuario in gestor.Usuarios) Console.WriteLine(usuario);
    if (gestor.Usuarios.Count > 0)
    {
        int usuarioId = LeerEntero("ID de usuario (0 para omitir): ");
        if (usuarioId != 0)
        {
            var filtradas = gestor.ReservasPorUsuario(usuarioId).ToList();
            if (filtradas.Count == 0) Console.WriteLine("No se encontraron reservas para ese usuario.");
            else foreach (var reserva in filtradas) Console.WriteLine(reserva);
        }
    }
}

static void CancelarReserva(GestorReservas gestor)
{
    int id = LeerEntero("Ingrese el ID de la reserva que desea cancelar: ");
    gestor.CancelarReserva(id);
    Console.WriteLine("Reserva cancelada. Los cupos fueron devueltos al evento.");
}

static void VerResumen(GestorReservas gestor)
{
    Console.WriteLine("RESUMEN DE RESERVAS ACTIVAS");
    Console.WriteLine($"Reservas activas: {gestor.CantidadReservasActivas}");
    Console.WriteLine($"Entradas reservadas: {gestor.CantidadEntradasActivas}");
    Console.WriteLine($"Valor total: {gestor.ValorTotalActivo:C0}");
}

static int LeerEntero(string mensaje)
{
    Console.Write(mensaje);
    string? entrada = Console.ReadLine();
    if (!int.TryParse(entrada, out int valor)) throw new FormatException("Debe ingresar un número entero válido.");
    return valor;
}
